import os
import json
import pickle
import cv2
import numpy as np
from django.conf import settings
from django.http import JsonResponse
from django.shortcuts import render
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from .models import Video
from .forms import VideoUploadForm
from .serializers import VideoSerializer
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from face_recognition import face_encodings, face_locations, face_distance

from django.shortcuts import get_object_or_404
from rest_framework.decorators import api_view
from .models import VerificationCode

@api_view(['GET'])
def get_verification_code(request, input_code):
    """
    Retrieves verification code details.
    """
    verification = get_object_or_404(VerificationCode, verification_code=input_code)
    return Response({
        'user_id': verification.user.id,
        'verification_code': verification.verification_code
    }, status=200)


# Match Form HTML
def match_form_html(request):
    """
    매칭 키 입력용 폼 HTML을 렌더링합니다.
    """
    return render(request, 'video_platform/match_form.html')


# Match Videos HTML
def match_videos_html(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body.decode('utf-8'))
        except json.JSONDecodeError:
            return JsonResponse({"error": "Invalid JSON input."}, status=400)

        key = data.get('key')
        if not key:
            return JsonResponse({"error": "Key is required."}, status=400)

        key_path = os.path.join(settings.MEDIA_ROOT, 'face_encodings', f"{key}.pkl")
        if not os.path.exists(key_path):
            return JsonResponse({"error": "Key file not found."}, status=404)

        try:
            with open(key_path, 'rb') as f:
                known_encodings = pickle.load(f)
                if not isinstance(known_encodings, list):
                    raise ValueError("Invalid encoding data format: Expected a list.")
        except Exception as e:
            return JsonResponse({"error": f"Failed to load key file: {str(e)}"}, status=500)

        videos_dir = os.path.join(settings.MEDIA_ROOT, 'videos')
        video_files = [os.path.join(videos_dir, f) for f in os.listdir(videos_dir) if f.endswith('.mp4')]

        matched_videos = []
        for video_path in video_files:
            cap = cv2.VideoCapture(video_path)
            fps = int(cap.get(cv2.CAP_PROP_FPS))
            frame_interval = max(fps // 2, 1)
            frame_count = 0
            matched = False

            while cap.isOpened():
                ret, frame = cap.read()
                if not ret:
                    break

                if frame_count % frame_interval == 0:
                    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    frame_encodings = face_encodings(rgb_frame)

                    if not frame_encodings:  # 얼굴 인코딩이 없으면 스킵
                        continue

                    for face_encoding in frame_encodings:
                        if not isinstance(face_encoding, np.ndarray):
                            continue

                        distances = face_distance(np.array(known_encodings), face_encoding)
                        best_match_index = np.argmin(distances)
                        best_distance = distances[best_match_index]

                        if best_distance < 0.6:
                            match_time = frame_count / fps
                            matched_videos.append({
                                "video_name": os.path.basename(video_path),
                                "first_match_time": float(match_time),
                                "match_similarity": float(best_distance)
                            })
                            matched = True
                            break

                if matched:
                    break

                frame_count += 1
            cap.release()

        return JsonResponse({"matched_videos": matched_videos}, status=200)

    return JsonResponse({"error": "Invalid request method."}, status=405)


# Upload Video
def upload_video(request):
    """
    HTML 렌더링을 통해 비디오 업로드를 처리하는 뷰
    """
    if request.method == 'POST':
        form = VideoUploadForm(request.POST, request.FILES)
        if form.is_valid():
            video_name = form.cleaned_data['video_name']
            video_file = form.cleaned_data['video_file']

            # Video 모델 인스턴스 생성 및 저장
            video = Video.objects.create(
                video_name=video_name,
                file_path=video_file
            )
            # 미디어 디렉토리에 파일 저장
            path = default_storage.save(video.file_path.name, ContentFile(video_file.read()))

            return render(request, 'video_platform/upload_success.html', {'video': video})
    else:
        form = VideoUploadForm()

    return render(request, 'video_platform/upload_video.html', {'form': form})


# REST API for Video Upload
class VideoUploadView(APIView):
    """
    Handles video upload via API (JSON request/response).
    """
    def post(self, request, *args, **kwargs):
        video_file = request.FILES.get('file')
        video_name = request.data.get('video_name')

        if not video_file or not video_name:
            return Response({"error": "Both video file and video name are required."}, status=status.HTTP_400_BAD_REQUEST)

        video_instance = Video(video_name=video_name, file_path=video_file.name)
        video_instance.save()

        video_path = os.path.join(settings.MEDIA_ROOT, video_file.name)
        with open(video_path, 'wb+') as destination:
            for chunk in video_file.chunks():
                destination.write(chunk)

        serializer = VideoSerializer(video_instance)
        return Response(serializer.data, status=status.HTTP_201_CREATED)


# REST API for Video List
class VideoListView(APIView):
    """
    Handles video list retrieval.
    """
    def get(self, request, *args, **kwargs):
        videos = Video.objects.all()
        serializer = VideoSerializer(videos, many=True)

        for video in serializer.data:
            video['file_path'] = request.build_absolute_uri(os.path.join(settings.MEDIA_URL, video['file_path']))

        return Response(serializer.data, status=status.HTTP_200_OK)

#추가함
def process_video_view(request):
    """
    동영상 처리 및 결과 반환
    """
    if request.method == 'POST':
        try:
            # 처리할 동영상 경로 설정
            video_dir = os.path.join(settings.MEDIA_ROOT, "videos")

            # video_processing.py 스크립트 실행
            script_path = os.path.join(settings.BASE_DIR, "video_processing.py")
            result = subprocess.run(
                ["python", script_path],
                capture_output=True,
                text=True,
                cwd=video_dir
            )

            # 결과 정리
            if result.returncode == 0:
                output = result.stdout
            else:
                output = result.stderr

            return JsonResponse({"result": output}, status=200)

        except Exception as e:
            return JsonResponse({"error": f"Error processing video: {str(e)}"}, status=500)

    return JsonResponse({"error": "Invalid request method."}, status=405)